import React from 'react'
import '../Components/profile.css'

const Profile = () => {
  return (
    <div>
    <div className="containercallus">
      <h2 id="companyname">Welcome </h2>
      <h3 id='developer'>Developer : BasavaKiran</h3>
      <h3>Address :Bangalore,Karntaka, India</h3>
      <h3>Phone : 1234567890</h3>
      <h3>Email : xyz@example.com</h3>
      <h3>Graduation : MCA</h3>
      <h3>College : AMC Engineering College , Bengaluru.</h3>
    </div>
  </div>

  )
}

export default Profile